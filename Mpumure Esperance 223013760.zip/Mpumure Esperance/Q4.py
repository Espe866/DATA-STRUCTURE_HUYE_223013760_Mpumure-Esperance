student_marks = [66, 51, 16, 76]
student_marks.reverse()
print(student_marks)