products = [
    ["Laptop", 100, 5],
    ["Headphones", 200, 0],
    ["Keyboard", 400, 10],
    ["Mouse", 50, 2],
    
]
in_stock_products = [product for product in products if product[2] > 0]
print("Products In Stock:", in_stock_products)