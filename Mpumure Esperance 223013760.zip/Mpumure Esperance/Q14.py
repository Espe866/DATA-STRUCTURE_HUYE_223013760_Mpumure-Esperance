todo_list = []
def add_task(task):
    todo_list.append(task)
    print(f"Added task: '{task}'")
def complete_task(task):
    if task in todo_list:
        todo_list.remove(task)
        print(f"Completed task: '{task}'")
    else:
        print(f"Task '{task}' not found in the list.")
def display_tasks():
    if todo_list:
        print("To-Do List:")
        for task in todo_list:
            print(f"- {task}")
    else:
        print("The to-do list is empty.")
add_task("DOING EXERCISE")
add_task("PREPARING LUNCH")
add_task("WASHING CLOTHES")
display_tasks()
complete_task("PREPARING LUNCH")
display_tasks()
