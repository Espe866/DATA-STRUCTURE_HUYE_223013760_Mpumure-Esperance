expenses = [
    [1000, 1100, 1050, 1020, 1070, 1100],  # Rent
    [300, 320, 310, 330, 340, 325],        # Food
    [150, 140, 160, 155, 165, 170]         # Utilities
]

def calculate_average_expenses(expenses):
    """ Calculate average expenses per category """
    averages = []
    for category_expenses in expenses:
        avg = sum(category_expenses) / len(category_expenses)
        averages.append(avg)
    return averages
average_expenses = calculate_average_expenses(expenses)
print("Average Monthly Expenses per Category:", average_expenses)
