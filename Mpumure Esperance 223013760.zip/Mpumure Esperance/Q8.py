image = [
    [[123, 234, 45], [255, 0, 0], [128, 128, 128]], 
    [[0, 255, 0], [0, 0, 255], [255, 255, 255]],    
    [[10, 20, 30], [40, 50, 60], [70, 80, 90]]      
]

def invert_colors(image):
    inverted_image = []
    
    for row in image:
        inverted_row = []
        for pixel in row:
            inverted_pixel = [255 - channel for channel in pixel]
            inverted_row.append(inverted_pixel)
        inverted_image.append(inverted_row)
    
    return inverted_image

def print_image(image):
    
    for row in image:
        print(row)


print("Original Image:")
print_image(image)

inverted_image = invert_colors(image)

print("\nInverted Image:")
print_image(inverted_image)
