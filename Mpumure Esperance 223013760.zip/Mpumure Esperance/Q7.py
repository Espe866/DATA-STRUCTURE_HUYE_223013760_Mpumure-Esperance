sales = [
    [130, 220, 330, 480, 250, 300, 190],    
]
def print_sales(sales_data):
    for product_sales in sales_data:
        print(f"week Products: {product_sales}")
print_sales(sales)