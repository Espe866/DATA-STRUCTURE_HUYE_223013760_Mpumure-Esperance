ages_list = [34, 7, 200, 40, 11]
# sorting ages
ages_list.sort()
print("sorted ages using the sorted():", ages_list)
