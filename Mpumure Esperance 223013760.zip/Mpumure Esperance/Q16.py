# List of students with name, age, and grade
students = [
    ["ANITHA", 20, 85],
    ["ALLEN", 21, 92],
    ["JACOB", 19, 78],
    ["JAVANY", 22, 88]
]

# Sort the list by grade (3rd element in each sublist)
students.sort(key=lambda student: student[2])

# Print the sorted list of students
print("Sorted Students by Grade:", students)