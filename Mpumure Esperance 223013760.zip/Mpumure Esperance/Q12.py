shoping_list =['SOAP','JELLY', 'RICE', 'BUTTER']
print(shoping_list)
# removing items
shoping_list.remove('RICE')
print(shoping_list)