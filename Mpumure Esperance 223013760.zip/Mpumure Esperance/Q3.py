satock_prices = [20, 18, 10, 45, 23, 29, 30]
max_prices = max(satock_prices)
min_prices = min(satock_prices)
print(satock_prices)
print(f"max_prices): $({max_prices:.2f}")
print(f"min_prices): $({min_prices:.2f}")
