seating = [
    ['O', 'O', 'O', 'O'],  
    ['O', 'O', 'O', 'O'],  
    ['O', 'O', 'O', 'O'],  
    ['O', 'O', 'O', 'O'],  
    ['O', 'O', 'O', 'O']   
]
seating[0][1] = 'X'  
seating[2][3] = 'X'  
seating[4][0] = 'X'  
print("Updated Seating Arrangement:")
for row in seating:
    print(row)