daily_sales = [122, 230, 100, 150, 200, 180, 124]
average_sales = sum(daily_sales) / len(daily_sales)
print(f"average_sales): $({average_sales}")
