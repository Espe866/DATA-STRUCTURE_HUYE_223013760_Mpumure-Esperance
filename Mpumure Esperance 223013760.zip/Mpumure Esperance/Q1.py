temperature_reading = [22, 23, 36, 46, 29, 14, 28]
print(temperature_reading)
print(f"temperature reading): ℃({temperature_reading}")