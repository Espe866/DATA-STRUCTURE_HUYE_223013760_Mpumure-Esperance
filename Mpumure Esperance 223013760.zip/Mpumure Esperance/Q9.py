total_marksmarks = [
    [79, 85, 93, 80,56],  
    [80, 77, 74, 91,87],  
    [60, 72, 85, 78,67],  
    [95, 89, 93, 96,89], 
    [77, 82, 79, 85,45]   
]

print("Marks of students in subjects:")
for marks in total_marksmarks:
    print(marks)

# Calculate the total marks for each student
total_marks = []
for marks in total_marksmarks:
    total = sum(marks)
    total_marks.append(total)

print("\nTotal marks of each student:")
for i, total in enumerate(total_marks, start=1):
    print(f"Student {i}: {total}")