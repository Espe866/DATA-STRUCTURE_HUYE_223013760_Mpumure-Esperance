friends_list_1 = ['PENINNAH', 'ANGEL', 'ESPE', 'JOJO']
friends_list_2 = ['CHANCE', 'ESPE', 'PENINNAH', 'JOJO']
merged_friends_list = list(set(friends_list_1 + friends_list_2))
print(merged_friends_list)