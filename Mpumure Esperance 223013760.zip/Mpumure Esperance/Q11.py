attended = ["ELLA", "YVE", "olga", "tom"]

# Display the current list of attendees
print("Attended:", attended)

# Adding a new name to the list
new_attended = "manzi"
attended.append(new_attended)

# Display the updated list of attendees
print("Updated Attended:", attended)