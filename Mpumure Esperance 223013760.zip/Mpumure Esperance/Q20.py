scores = [
    ["Plr 1", [30, 25, 40]],  
    ["Plr 2", [40, 15, 30]],  
    ["Plr 3", [5, 20, 25]]    
]

def find_winner(scores):
    """ Function to find the winner based on highest average score """
    highest_avg = 0
    winner = None
    for plr in scores:
        player_name, player_scores = plr
        avg_score = sum(player_scores) / len(player_scores)
        if avg_score > highest_avg:
            highest_avg = avg_score
            winner = player_name
    return winner, highest_avg

# Find the winner
winner, avg_score = find_winner(scores)

# Print the winner and their average score
print(f"The winner is {winner} with an average score of {avg_score:.2f}")
