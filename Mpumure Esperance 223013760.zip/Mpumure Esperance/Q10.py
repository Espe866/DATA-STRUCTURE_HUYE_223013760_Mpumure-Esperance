temperatures = [
    [30, 32, 31, 29, 30, 31, 32],  # City 1: Temperatures for 7 days
    [25, 26, 27, 26, 28, 29, 27],  # City 2: Temperatures for 7 days
    [15, 17, 16, 16, 15, 16, 18],  # City 3: Temperatures for 7 days
    [22, 23, 24, 22, 21, 23, 24]   # City 4: Temperatures for 7 days
]

def calculate_average_temperatures(temps):
    """ Function to calculate average temperature for each city """
    average_temperatures = []
    
    for city_temps in temps:
        total = sum(city_temps)  # Sum the temperatures for each city
        average = total / len(city_temps)  # Calculate average for the city
        average_temperatures.append(average)  # Store the average
    
    return average_temperatures

def print_average_temperatures(average_temperatures):
    """ Function to print the average temperature for each city """
    for city_index, avg_temp in enumerate(average_temperatures, 1):
        print(f"City {city_index} Average Temperature: {avg_temp:.2f}°C")

average_temperatures = calculate_average_temperatures(temperatures)

print_average_temperatures(average_temperatures)
